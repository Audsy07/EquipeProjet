package com.fr.adaming.service;

public class TeamServiceTests {

}
